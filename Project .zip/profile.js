function showPics(){
  const el = document.getElementById("image");
  el.src = "/Project /IMG-20241129-WA0017.jpg";
  return el;
}