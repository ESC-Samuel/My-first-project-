const name = document.getElementById("name").value = "samuel";
const number = document.getElementById("number").value = "07014024458";
const pin = document.getElementById("pin").value = "5050";
let inputs = (name) || (number) || (pin);
if (inputs) {
 (Login) => {
     /*Tab to edit*/
     document.getElementById("a");
 }
}
else {
  document.getElementById("incorrect").innerText = "incorrect details";
}